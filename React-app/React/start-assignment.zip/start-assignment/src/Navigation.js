import React from "react";
import { Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function Navigation() {
  return (
    <div className="bg-dark">
      <ul className="container d-flex">
        <li className="m-2">
          <Link to="/">Assignment-1</Link>
        </li>
        <li  className="m-2">
          <Link to="/Assignmenttwo">Assignment-2</Link>
        </li>
        <li  className="m-2">
          <Link to="/Assingmentthree">Assignment-3</Link>
        </li>
        <li  className="m-2">
          <Link to="/Assignmentfour">Assignment-4</Link>
        </li>
        <li className="m-2">
          <Link to="/Assignmentfive">Assignment-5</Link>
        </li>
        <li className="m-2">
          <Link to="/AssignmentfiverRep">Assignment-5 Rep</Link>
        </li>
        <li className="m-2">
          <Link to="/Assignmentsix">Assignment-6</Link>
        </li>
        <li className="m-2">
          <Link to="/Assignmenteight">Assignmenteight-8</Link>
        </li>
      </ul>
    </div>
  );
}

export default Navigation;
