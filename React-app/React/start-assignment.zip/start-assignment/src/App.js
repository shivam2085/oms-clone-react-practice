import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Assignmentone from "./Pages/Assignmentone";
import Assignmenttwo from "./Pages/Assignmenttwo";
import Assingmentthree from "./Pages/Assingmentthree";
import Navigation from "./Navigation";
import Assignmentfour from "./Pages/Assignmentfour";
import Assignmentfive from "./Pages/Assignmentfive";
import AssignmentfiverRep from "./Pages/AssignmentfiverRep";
import Assignmentsix from "./Pages/Assignmentsix";
import Post from "./Pages/Post";
import Assignmenteight from "./Pages/Assignmenteight";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navigation />
        <Routes>
          <Route path="/" element={<Assignmentone />}></Route>
          <Route path="/Assignmenttwo" element={<Assignmenttwo />}></Route>
          <Route path="/Assingmentthree" element={<Assingmentthree />}></Route>
          <Route path="/Assignmentfour" element={<Assignmentfour />}></Route>
          <Route path="/Assignmentfive" element={<Assignmentfive />}></Route>
          <Route path="/AssignmentfiverRep" element={<AssignmentfiverRep />}></Route>
          <Route path="/Assignmentsix" element={<Assignmentsix />}></Route>
          <Route path="/Assignmentsix/:id" element={<Post />}></Route>
          <Route path="/Assignmenteight" element={<Assignmenteight />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
