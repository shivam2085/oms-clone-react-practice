import React, { useEffect, useState } from "react";
import BorderColorIcon from "@mui/icons-material/BorderColor";

const Assignmentfive = () => {
  const [name, setName] = useState("");
  const [lastName, setlastName] = useState("");
  const [Age, setAge] = useState();
  const [Rollno, setRollno] = useState();
  const [datas, setData] = useState([]);
  const [ferror, FildError] = useState({});

  
  function handleForm(e) {
    e.preventDefault();
    const dataObject = {
      Name: name,
      LastName: lastName,
      Age: Age,
      Rollno: Rollno,
    };
    let data = [...datas];
    //  data.push(dataObject);
    // if(dataObject.Name.length&&dataObject.LastName.length&&dataObject.Age.length){
    // }

    if (FormValidate() === true) {
      console.log("form has Submited");
      setData([...data, dataObject]);
      setName("");
      setlastName("");
      setAge("");
      setRollno("");
    } else {
      console.log("form Not Submited");
    }
  }

  function FormValidate() {
    const error = {};
    let isvalidates = true;

    let RegName = /^[A-Z]+[a-zA-Z]*$/;
    let a = name.match(RegName);
    if (name.length === 0) {
      error.name = "Please Enter Name";
      isvalidates = false;
    } else if (!a) {
      error.name = "Please Enter Valid Name and first Letter Shuld Capital";
      isvalidates = false;
    }

    let regLname = /^[A-Z]+[a-zA-Z]*$/;
    let b = lastName.match(regLname);
    if (lastName.length === 0) {
      error.lastName = "Please Enter last Name";
      isvalidates = false;
    } else if (!b) {
      error.lastName =
        "Please Enter Valid Last Name and first Letter Shuld Capital";
      isvalidates = false;
    }

    let AgeEx = /^[0-9]*$/;
    let c = Age.match(AgeEx);
    if (Age.length > 2) {
      error.Age = "Please Enter min 2 Number";
      isvalidates = false;
    } else if (!c) {
      error.Age = "Please Do Not Enter Character";
      isvalidates = false;
    } else if (Age.length === 0) {
      error.Age = "Please Enter Age";
      isvalidates = false;
    }

    let Roll = /^[0-9]*$/;
    let d = Rollno.match(Roll);
    if (Rollno.length === 0) {
      error.Rollnos = "Please Enter min 2 Number";
      isvalidates = false;
    } else if (!d) {
      error.Rollnos = "Please Do Not Enter Character";
      isvalidates = false;
    }

    FildError(error);
    return isvalidates;
  }

  // useEffect(() => {
  //   console.log(editData, "editData");
  //   let data = [...datas];
  //   data?.splice(editData, 2);
  //   setData(data);
  // }, [editData]);

  const EditData=(index)=> {
    let data = [...datas]
    data.splice(index,1)
    setData(data)
  }
  return (
    <>
      <form onSubmit={handleForm}>
        <div className="mb-3 Main-div">
          <label className="fw-bold">First Name: </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          ></input>
          {<span className="erremsg">{ferror.name}</span>}
        </div>
        <div className="mb-3 Main-div">
          <label className="fw-bold">Last Name:</label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setlastName(e.target.value)}
          ></input>{" "}
          {<span className="erremsg">{ferror.lastName}</span>}
        </div>
        <div className="mb-3 Main-div">
          <label className="fw-bold">Age:</label>
          <input
            type="text"
            value={Age}
            onChange={(e) => setAge(e.target.value)}
          ></input>
          {<span className="erremsg">{ferror.Age}</span>}
        </div>
        <div className="mb-3 Main-div">
          <label className="fw-bold">Roll No:</label>
          <input
            type="text"
            value={Rollno}
            onChange={(e) => setRollno(e.target.value)}
          ></input>
          {<span className="erremsg">{ferror.Rollnos}</span>}
        </div>
        <button type="submit">Submit</button>
      </form>
      <div>
        <table>
          <thead>
            <tr>
              <td>First Name</td>
              <td>Last Name</td>
              <td>Age</td>
              <td>Roll No</td>
              <td>Action</td>
            </tr>
          </thead>
          <tbody>
            {datas?.map((item, index) => (
              <tr key={item.Rollno}>
                <td>{item.Name} </td>
                <td>{item.LastName} </td>
                <td>{item.Age} </td>
                <td>{item.Rollno}</td>
                <td
                  className="pointer"
                  onClick={() => EditData(index)}
                >Delete</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Assignmentfive;
