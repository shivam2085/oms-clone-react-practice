import React, { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";

function Assingmentthree() {
  const [first, setFirst] = useState( );
  const [second, setSecond] = useState( );
  const [result, setResult] = useState( );

    function sumTwon() {
      // alert("test")
      setResult(parseInt(first) + parseInt(second)) 
      console.log(first);
      console.log(second);
    };

  return (
    <div>
      <input
        type="text"
        value={first}
        className="mb-4"
        onChange={(e) => setFirst(e.target.value)}
      />
      <br />
      <input
        type="text"
        value={second}
        className="mb-4"
        onChange={(e) => setSecond(e.target.value)}
      />
      <br />
      <button onClick={sumTwon}>ADD</button>
      <h1>{result}</h1>
    </div>
  );
}

export default Assingmentthree;
