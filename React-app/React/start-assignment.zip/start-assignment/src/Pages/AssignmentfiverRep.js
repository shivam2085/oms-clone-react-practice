import { Label } from "@mui/icons-material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Assignmenteight from "./Assignmenteight";

const AssignmentfiverRep = () => {
  // const navigate =useNavigate()
  let rahul = 12;
  console.log(rahul,"rahul first");
  const [data, setdata] = useState({
    id: "",
    fname: "",
    lname: "",
  });
  const [allData, setAllData] = useState([]);
  function addList(e) {
    e.preventDefault();
    setAllData([...allData, data]);
    // navigate("/Assignmenteight",{ state: allData })
  }
  // console.log(allData);
  useEffect(() => {
    setdata({
      id: "",
      fname: "",
      lname: "",
    });
  }, [allData]);
  return (
    <>
      <form onSubmit={addList}>
        <div className="mb-3">
          <label>ID</label>
          <input
            type="text"
            onChange={(e) => setdata({ ...data, id: e.target.value })}
            value={data.id}
          ></input>
        </div>
        <div className="mb-3">
          <label>Name</label>
          <input
            type="text"
            onChange={(e) => setdata({ ...data, fname: e.target.value })}
            value={data.fname}
          ></input>
        </div>
        <div className="mb-3">
          <label>Last Name</label>
          <input
            type="text"
            onChange={(e) => setdata({ ...data, lname: e.target.value })}
            value={data.lname}
          ></input>
        </div> 
        <button type="submit">Submit</button>
      </form>
      <div>

       <Assignmenteight rahul={rahul} data={allData} />
        {/* <table>
          <thead>
            <tr>
              <td>Name</td>
              <td>Last Name</td>
              <td>Roll</td>
            </tr>
          </thead>
          <tbody>
            {allData.map((item,index) => (
              <tr key={index}>
                <td>{item.fname}</td>
                <td>{item.lname}</td>
                <td>{item.id}</td>
              </tr>
            ))}
          </tbody>
        </table> */}
      </div>
    </>
  );
};

export default AssignmentfiverRep;
