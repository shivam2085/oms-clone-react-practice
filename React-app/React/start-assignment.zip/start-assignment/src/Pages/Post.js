import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

export const Post = () => {
  const param = useParams();
  const [responas, setRespon] = useState([]);

  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/posts/${param.id}`).then(
      (result) => {
        result.json().then((resp) => {
          setRespon(resp);
        });
      }
    );
  });
  return (
    <div>
      <ul className="fw-bold">
        <li>{responas.id}</li>
        <li>{responas.userId}</li>
        <li>{responas.title}</li>
        <li>{responas.body}</li>
      </ul>
      <button className="btn"><Link to={"/Assignmentsix"}>Back</Link></button>
    </div>
  );
};
export default Post;
