import React, { useState } from "react";

function Assignmentfour() {
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");
  const [ages, setAge] = useState("");
  const [MobNumbers, setMobNumber] = useState("");
  const [errMsg, setErrMsg] = useState({});

  function handleSubmit(event) {
    event.preventDefault(event);
    setFname("");
    setLname("");
    setAge("");
    setMobNumber("");
    if (validationcheck()) {
      console.log("Form has Submited");
    } else {
      setFname(fname);
      setLname(lname);
      setAge(ages);
      setMobNumber(MobNumbers);
    }
  }

  // validation
  const validationcheck = () => {
    const error = {};
    let isValidate = true;

    let Rex = /^[A-Z]+[a-zA-Z]*$/;
    let a = fname.match(Rex);
    if (fname.length === 0) {
      error.fname = "Please enter first name.";
      isValidate = false;
      // console.log(error.fname);
    } else if (!a) {
      error.fname =
        "Please enter valid first name and First letter is capital.";
      isValidate = false;
    }

    let lastEx = /^[A-Z]+[a-zA-Z]*$/;
    let b = lname.match(lastEx);
    if (lname.length === 0) {
      error.lname = "Please enter Last name.";
      isValidate = false;
    } else if (!b) {
      error.lname = "Please valid enter Last name and First letter is capital.";
      isValidate = false;
    }

    let ageEx = /^[0-9]*$/;
    let ageN = ages.match(ageEx);
    if (ages.length > 2) {
      error.age = "Please enter age";
      isValidate = false;
    } else if (!ageN) {
      error.age = "Please enter valid age";
      isValidate = false;
    } else if (ages.length === 0) {
      error.age = "Please enter age";
      isValidate = false;
    }

    let NumbEx = /^\d{10}$/;
    let MobNumber = MobNumbers.match(NumbEx);
    if (MobNumbers.length === 0) {
      error.Number = "Please enter valid mobile number";
      isValidate = false;
    } else if (!MobNumber) {
      error.Number = "Please enter 10 digit mobile number";
      isValidate = false;
    }

    setErrMsg(error);
    return isValidate;
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div className="Main-div">
          <label className="px-1">First Name: </label>
          <input
            type="text"
            value={fname}
            className="mb-4"
            onChange={(e) => setFname(e.target.value)}
          />
          {<span className="erremsg">{errMsg.fname}</span>}
        </div>
        <div className="Main-div">
          <label className="px-1">Last Name: </label>
          <input
            type="text"
            value={lname}
            className="mb-4"
            onChange={(e) => setLname(e.target.value)}
          />
          {<span className="erremsg">{errMsg.lname}</span>}
        </div>
        <div className="Main-div">
          <label className="px-1">Age: </label>
          <input
            type="text"
            value={ages}
            className="mb-4"
            onChange={(age) => setAge(age.target.value)}
          />
          {<span className="erremsg">{errMsg.age}</span>}
        </div>
        <div className="Main-div">
          <label className="px-1">Mobile Number: </label>
          <input
            type="text"
            value={MobNumbers}
            className="mb-4"
            onChange={(Mn) => setMobNumber(Mn.target.value)}
          />
          {<span className="erremsg">{errMsg.Number}</span>}
        </div>
        <br />
        <button type="submit" value="submit">
          Submit
        </button>
      </form>
    </div>
  );
}

export default Assignmentfour;
