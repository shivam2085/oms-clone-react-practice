import React from 'react'
import { useState } from 'react'

function Assignmenttwo() {
  const [data,setData]=useState("")
  return (
    <div>
      <input type="text" onChange={(e)=>setData(e.target.value)} /> 
      <h1>{data}</h1>
    </div>
  )
}

export default Assignmenttwo