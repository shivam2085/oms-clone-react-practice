import React from 'react'

function Assignmentone() {
  return (
    <div><h1 className='m-5'>Hello World</h1></div>
  )
}

export default Assignmentone