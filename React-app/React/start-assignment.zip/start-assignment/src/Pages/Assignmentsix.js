import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export const Assignmentsix = () => {
  const [apidata, setApidata] = useState([]);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts").then((result) => {
      result.json().then((resp) => {
        setApidata(resp);
      });
    });
  }, [apidata]);


  // useEffect(()=>{
  //   const posts = [
  //     {
  //       "id": 1,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 2,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 3,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 4,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 5,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 6,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 7,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 8,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 9,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 10,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 11,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 12,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 13,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 14,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 15,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 16,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 17,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 18,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 19,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "id": 20,
  //       "userid": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //   ];
  //   setApidata(posts)
  // },[])

  return (
    <>
      <div>
        <table>
          <thead>
            <tr>
              <td className="fw-bold">ID</td>
              <td className="fw-bold">USER Id</td>
              <td className="fw-bold">TITLE</td>
              <td className="fw-bold">BODY</td>
            </tr>
          </thead>
          <tbody>
            {apidata.map((item) => (
              <tr key={item.id}>
                <td><Link to={`/Assignmentsix/${item.id}`}>{item.id}</Link></td>
                <td>{item.userid}</td>
                <td>{item.title}</td>
                <td>{item.body}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};
export default Assignmentsix;
