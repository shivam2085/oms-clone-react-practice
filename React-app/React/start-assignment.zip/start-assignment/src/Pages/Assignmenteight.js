import React, { useState } from "react";
import { useLocation } from "react-router-dom";

export const Assignmenteight = (data2) => {
  const  {data,rahul}=data2
  // rahul=13;
    const location =useLocation()
    console.log(data2,"Rahul");
    console.log(location,"location");
  return (
    <>
      <div>Assignmenteight </div>
      <table>
        <thead>
          <tr>
            <td>Name</td>
            <td>Last Name</td>
            <td>Roll</td>
          </tr>
        </thead>
        <tbody>
          {data?.map((item, index) => (
            // console.log(item,"item in map"),
            <tr key={index}>
              <td>{item.id}</td>
              <td>{item.fname}</td>
              <td>{item.lname}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};
export default Assignmenteight;
