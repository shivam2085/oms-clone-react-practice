import React, { createContext, useState } from "react";

export const userContexts = createContext(null);

function GlobalData({ children }) {
  const data = localStorage.getItem("accesToken");
  const [isLogin, setIsLogin] = useState(data);
  return (
    <userContexts.Provider value={{ login: isLogin, setlogin: setIsLogin }}>
      {children}
    </userContexts.Provider>
  );
}

export default GlobalData;

// import React from 'react'

// function Test(props) {
//   return (
//     <div>{props.childred}</div>
//   )
// }

// <Test d="asdf">

//     dafsdfsafsafsdfdsfsdf
// </Test>
