import axios from "axios";
import React, { useEffect, useState } from "react";
import moment from "moment/moment";
import DeleteIcon from "@mui/icons-material/Delete";
import InfoIcon from "@mui/icons-material/Info";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import SearchIcon from "@mui/icons-material/Search";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import LastPageIcon from "@mui/icons-material/LastPage";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const Call = () => {
  const [list, setlist] = useState();
  const [page, setPage] = useState(0);
  const [callCount, setCallCount] = useState();

  const getlist = () => {
    const url = "https://staging-api.digitaloms.in/call-logs/list";
    const paylod = {
      page: {
        number: page,
        size: 10,
      },
    };
    axios
      .post(url, paylod, {
        headers: {
          authorization: `Bearer ${localStorage.getItem("accesToken")}`,
        },
      })
      .then((rep) => {
        setlist(rep.data[0]);
        setCallCount(rep.data[1]);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getlist();
  }, [page]);

  return (
    <>
      <div className="container-fluid">
        <div className="main-contain">
          <div className="d-flex justify-content-between mb-2 top-head">
            <div className="fw-bold px-3 pt-1">Call ( {callCount} )</div>
            <div className="d-flex justify-content-between">
              {" "}
              <button className="excel-d">
                <DownloadForOfflineIcon className="p-1" />
                Excel
              </button>
              <div className="position-relative mx-1">
                <input
                  type="search"
                  className="search-heade p-1"
                  placeholder="Search by Name/Phone/Aadhar"
                />
                <SearchIcon className="search-icon" />
              </div>
              <button className="table-button">
                <FilterAltIcon />
              </button>
              <button className="table-button" style={{ color: "gray" }}>
                <MoreVertIcon />
              </button>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th></th>
                <th>Date</th>
                <th>Name</th>
                <th>Mobile Number</th>
                <th>E-mail</th>
                <th>Priority</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {list?.map((i, index) => {
                console.log(i.id);
                return (
                  <>
                    <TableRow i={i} />
                  </>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="pagenation">
          <div className="row">
            <div className="col-1"></div>
            <div className="col-1"></div>
            <div className="col-1">
              <button onClick={() => setPage(0)} className="page-btn">
                <FirstPageIcon />
              </button>
            </div>
            <div className="col-1">
              <button
                className="page-btn"
                onClick={() => {
                  if (page > 0) {
                    setPage(page - 1);
                  }
                }}
              >
                <ChevronLeftIcon />
              </button>
            </div>
            <div className="col-1">
              <button className="page-btn" onClick={() => setPage(page)}>
                {page}
              </button>
            </div>
            <div className="col-1">
              <button className="page-btn" onClick={() => setPage(page)}>
                {page}
              </button>
            </div>
            <div className="col-1">
              <button className="page-btn" onClick={() => setPage(page)}>
                {page}
              </button>
            </div>
            <div className="col-1">
              <button className="page-btn" onClick={() => setPage(page)}>
                {page}
              </button>
            </div>
            <div className="col-1">
              <button className="page-btn" onClick={() => setPage(page)}>
                {page}
              </button>
            </div>
            <div className="col-1">
              <button
                className="page-btn"
                onClick={() => {
                  if (page < 7) {
                    setPage(page + 1);
                  }
                }}
              >
                <ChevronRightIcon />
              </button>
            </div>
            <div className="col-1">
              <button className="page-btn" onClick={() => setPage(7)}>
                <LastPageIcon />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Call;

const TableRow = (props) => {
  const { i } = props;
  const [exapndcomponent, setExapndComponent] = useState(false);
  const [userObject, setUserObject] = useState();
  console.log("userObject", userObject);
  const expand = () => {
    setExapndComponent(!exapndcomponent);
  };
  useEffect(() => {
    deletData();
  }, []);

  const deletData = async () => {
    const listData = i;
    // console.log(listData);
    setUserObject(listData);

    const url = "https://staging-api.digitaloms.in/call-logs/";

    const body = userObject;
    // console.log("body", body);
    var config = {
      url: `${url}${i.id}`,
      method: "put",
      data: body,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/plain, */*",
      },
    };

    await axios(config)
      .then((respon) => {
        console.log("deleted",respon);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <tr key={i?.callFrom.uniqueId}>
        <td className=" ">
          <button onClick={() => expand()} className="show-btn">
            {exapndcomponent ? <ExpandMoreIcon /> : <ChevronRightIcon />}
          </button>
        </td>
        <td>{moment(i?.date).add(10, "days").calendar(23)}</td>
        <td>
          <div>{i?.callFrom.uniqueId}</div>
          <div>
            {i?.callFrom.firstName}&nbsp;{i?.callFrom.lastName}
          </div>
        </td>
        <td>{i?.callFrom.phone}</td>
        <td>{i?.callFrom.email === null ? "--" : i?.callFrom.email}</td>
        <td>{i?.priority}</td>
        <td>
          {i?.recordStatus === "CREATED" ? (
            <button onClick={() => deletData()}>
              <DeleteIcon />
            </button>
          ) : (
            <>
              <InfoIcon />
              <span>Delete</span>
            </>
          )}
        </td>
      </tr>

      {/* First row close */}

      {/* second row start */}
      {exapndcomponent ? (
        <tr className="">
          {/* <td className="first-row"></td> */}
          <td colSpan={7} className="w-100 main-row">
            <div className="d-flex" style={{ gap: "20px" }}>
              <div className="w-50 addres-data p-4">
                <h5 className="adresa-head">Address Details</h5>
                <div className="row justify-content-evenly">
                  <div className="col-6">
                    <div className="row">
                      <div className="col-4 fw-bold">Assembly</div>
                      <div className="col-8">
                        {" "}
                        :{" "}
                        {i?.assembly?.name === null ? "--" : i?.assembly?.name}
                      </div>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="row">
                      <div className="col-4 fw-bold">City Type</div>
                      <div className="col-8">
                        : {i?.cityType === null ? "--" : i?.cityType}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row justify-content-evenly">
                  <div className="col-6">
                    <div className="row">
                      <div className="col-4 fw-bold">Ward</div>
                      <div className="col-8">
                        : {i?.prabhag?.name === null ? "--" : i?.prabhag?.name}
                      </div>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="row">
                      <div className="col-4 fw-bold">Ward Area</div>
                      <div className="col-8">
                        :{" "}
                        {i?.prabhagArea?.name === null
                          ? "--"
                          : i?.prabhagArea?.name}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="w-50 addres-data p-2 px-3">
                <h5 className="adresa-head">Note</h5>
                {i?.notes === null ? "--" : i?.notes}
              </div>
            </div>
          </td>
        </tr>
      ) : null}
    </>
  );
};
