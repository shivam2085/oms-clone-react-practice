import React from 'react'

const Todo = () => {
  return (
    <h1>Todo</h1>
  )
}

export default Todo