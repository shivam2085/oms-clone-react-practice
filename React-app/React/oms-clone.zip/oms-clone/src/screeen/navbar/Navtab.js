import React, { useContext, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { userContexts } from "../../context/Context";
import PersonIcon from '@mui/icons-material/Person';
import SearchIcon from '@mui/icons-material/Search';

const Navtab = () => {
  // const token = localStorage.getItem("uname");
  const { login, setlogin } = useContext(userContexts);

  const navigate = useNavigate();

  function logout(e) {
    e.preventDefault();
    // localStorage.clear();
    localStorage.clear();
    setlogin(false);
    navigate("/log");
  }

  return (
    <div>
      {login ? (
        <>
          <div className="d-flex navbar-top align-items-center">
              <div className="main-h">
                <Link to="/home">Office Management System</Link>
              </div>
            <ul className="d-flex m-0 align-items-center">
              <div className="position-relative">
                <input type="search" className="search-heade" placeholder="Search by Name/Phone/lastName" />
                <SearchIcon className="search-icon"/>
              </div>
              <li className="m-2">
                <Link to="/home">Dashboard</Link>
              </li>
              <li className="m-2">
                <Link to="/register">Register</Link>
              </li>
              <li className="m-2">
                <Link to="/schedule">Schedule</Link>
              </li>
              <li className="m-2">
                <Link to="/complaints">Complaints</Link>
              </li>
              <li className="m-2">
                <Link to="/visitors">Visitors</Link>
              </li>
              <li className="m-2">
                <Link to="/call">Call</Link>
              </li>
              <li className="m-2">
                <Link to="/todo">Todo</Link>
              </li>
              <button className="logout-icon" onClick={logout}><PersonIcon /></button>
            </ul>
            </div>
        </>
      ) : (
        // <>{navigate("/log")}</>
        <div className="position-absolute">
          <Link to="/log"></Link>
        </div>
      )}
    </div>
  );
};

export default Navtab;
