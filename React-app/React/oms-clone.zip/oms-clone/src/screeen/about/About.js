import React from 'react'

export const About = () => {
  return (
    <h1>Register
    </h1>
  )
}

export default About