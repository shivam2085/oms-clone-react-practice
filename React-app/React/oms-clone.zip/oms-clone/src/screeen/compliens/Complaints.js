import React from 'react'

const Complaints = () => {
  return (
    <h1>Complaints</h1>
  )
}

export default Complaints