import React, { useContext, useEffect, useState } from "react";
import officeSystem from "../assets/officeSystem.webp";
import TextField from "@mui/material/TextField";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import { userContexts } from "../context/Context";
import axios from "axios";
import { useNavigate } from "react-router-dom";
function Login() {
  const [uname, setUname] = useState();
  const [password, setPassord] = useState();
  const { login, setlogin } = useContext(userContexts);
  // console.log(login);
  function submitHandle(evt) {
    evt.preventDefault();
    // localStorage.setItem("uname", uname);
    const url = "https://staging-api.digitaloms.in/user/auth/login";
    const body = {
      username: uname,
      // "super.admin",
      password: password,
      // "super@123",
      // accessToken:
      //   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sZSI6IlNVUEVSX0FETUlOIiwidXNlcm5hbWUiOiJzdXBlci5hZG1pbiIsIm9pZCI6MSwiYWNjZXNzQ29udHJvbElkIjoxLCJpYXQiOjE2ODA2OTczNTgsImV4cCI6MTY4MDcyNjE1OH0.OUvC3hEHf97IgIjrNYk2JLZN-JTyZokEnVsicP0G_FU",
    };
    axios
      .post(url, body)
      .then((respons) => {
        localStorage.setItem("accesToken", respons.data.accessToken)
        setlogin(respons.data.accessToken);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <div className="main-bg">
      <div className="form-bg">
        <h5>Office Management System </h5>
        <img src={officeSystem} alt="OMS" className="avatar-icon shadow" />
        <form onSubmit={submitHandle}>
          <div className="mb-3 input-filds">
            <TextField
              id="standard-basic"
              label="User Name"
              variant="standard"
              onChange={(e) => setUname(e.target.value)}
            />
          </div>
          <div className="mb-4 input-filds">
            <TextField
              id="standard-password-input"
              label="Password"
              type="password"
              autoComplete="current-password"
              variant="standard"
              onChange={(e) => setPassord(e.target.value)}
            />
            <VisibilityOffIcon className="eyeicon" />
          </div>
          <button type="submit" className="login-btn mt-3">
            Log in
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
