import React, { useContext } from 'react'

const Contact = () => {
  return (
    <h1>Schedule</h1>
  )
}

export default Contact