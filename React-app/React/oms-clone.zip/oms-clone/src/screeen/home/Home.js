import React from 'react'

const Home = () => {
  return (
    <h1>Dashboard</h1>
  )
}

export default Home