import React from 'react'

const Visitors = () => {
  return (
    <h1>Visitors</h1>
  )
}

export default Visitors