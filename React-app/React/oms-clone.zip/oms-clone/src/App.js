import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Login from "./screeen/Login";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Navtab from "./screeen/navbar/Navtab";
import Home from "./screeen/home/Home";
import About from "./screeen/about/About";
import Contact from "./screeen/contact/Contact";
import GlobalData, { userContexts } from "./context/Context";
import { useContext } from "react";
import Complaints from "./screeen/compliens/Complaints";
import Visitors from "./screeen/visitors/Visitors";
import Call from "./screeen/call/Call";
import Todo from "./screeen/todo/Todo";
// import React, { createContext, useState } from "react";

// export const userContexts = createContext(null);?
function App() {
  // const token = localStorage.getItem("uname");
  // const [isLogin,setIsLogin] = useState(false)
  const { login, setlogin } = useContext(userContexts);

  return (
    <>
      {/* <userContexts.Provider value={{login:isLogin,setlogin:setIsLogin}}> */}
      <BrowserRouter>
        <Navtab />
        <Routes>
          {login ? (
            <>
              <Route path="/Home" element={<Home />}></Route>
              <Route path="/register" element={<About />}></Route>
              <Route path="/schedule" element={<Contact />}></Route>
              <Route path="/complaints" element={<Complaints />}></Route>
              <Route path="/visitors" element={<Visitors />}></Route>
              <Route path="/call" element={<Call />}></Route>
              <Route path="/todo" element={<Todo />}></Route>
            </>
          ) : (
            <>
              <Route path="/log" element={<Login />}></Route>
              <Route path="*" element={<Login />}></Route>
            </>
          )}
        </Routes>
      </BrowserRouter>
      {/* </ userContexts.Provider> */}
    </>
  );
}

export default App;
