import React, { useContext, useState } from "react";
import { userContext } from "./context/Context";
import axios from "axios";

const Login = () => {
  const [uname, setUname] = useState();
  const [pas, setPass] = useState();

  const { uenter, setEnter } = useContext(userContext);

  function handlesubmit(e) {
    e.preventDefault();
    // localStorage.setItem("name", uname);
    const url = "https://staging-api.digitaloms.in/user/auth/login";
    const body = {
      username: uname,
      password: pas,
    };
    axios
      .post(url, body)
      .then((respons) => {
        localStorage.setItem("accesToken", respons.data.accessToken)
        setEnter(respons.data.accessToken);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <div className="form">
      <form onSubmit={handlesubmit}>
        <div className="input-container">
          <label>Username </label>
          <input
            type="text"
            name="uname"
            required
            onChange={(e) => setUname(e.target.value)}
          />
        </div>
        <div className="input-container">
          <label>Password </label>
          <input
            type="password"
            name="pass"
            required
            onChange={(e) => setPass(e.target.value)}
          />
        </div>
        <div className="button-container">
          <button type="submit" >Submit</button>
        </div>
      </form>
    </div>
  );
};

export default Login;
