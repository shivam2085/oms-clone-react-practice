import React, { createContext, useState } from "react";

export const userContext = createContext(null);

const Contextdata = ({ children }) => {
 const data = localStorage.getItem("accesToken")
  const [enter, setEnter] = useState(data);
  return (
    <>
      <userContext.Provider value={{ uenter: enter, setEnter: setEnter }}>
        {children}
      </userContext.Provider>
    </>
  );
};

export default Contextdata;