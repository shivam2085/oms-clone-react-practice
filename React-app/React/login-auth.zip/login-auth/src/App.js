import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./screen/Home";
import About from "./screen/About";
import Conact from "./screen/Conact";
import Navbar from "./navbar/Navbar";
import Login from "./Login";
import Contextdata, { userContext } from "./context/Context";
import { useContext } from "react";

function App() {
  // const tokan = localStorage.getItem("name");
  const { uenter, setEnter } = useContext(userContext);
  // console.log(uenter);
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          {uenter ? (
            <>
              <Route path="/home" element={<Home />}></Route>
              <Route path="/about" element={<About />}></Route>
              <Route path="/contact" element={<Conact />}></Route>
            </>
          ) : (
            <>
              {" "}
              <Route path="/" element={<Login />}></Route>
              <Route path="/login" element={<Login />}></Route>
            </>
          )}
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
