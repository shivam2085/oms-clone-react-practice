import React, { useContext, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { userContext } from "../context/Context";

const Navbar = () => {
  // const tokan = localStorage.getItem("name");
  const {uenter, setEnter} = useContext(userContext);
  const naviget = useNavigate();

  function logout(e) {
    e.preventDefault();
    localStorage.clear()
    setEnter(false);
    naviget("/Login");
  }

  return (
    <>
      {uenter ? (
        <>
          <ul>
            <li>
              <Link to="/home">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">contact</Link>
            </li>
            <li>
              <button onClick={logout}>LOG OUT</button>
            </li>
          </ul>
        </>
      ) : (
        <div>
          <Link to="/Login"></Link>
        </div>
      )}
    </>
  );
};

export default Navbar;
