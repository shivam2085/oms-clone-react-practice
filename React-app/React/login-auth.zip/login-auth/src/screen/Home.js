import React from "react";
import axios from "axios";

const Home = () => {
  return (
    <>
      <h1>Home</h1>
    </>
  );
};

export default Home;
