import React from 'react'

const Conact = () => {
  return (
    <h1>Conact</h1>
  )
}

export default Conact